<?php
$seed_csp4_settings_deafults = array (
  'seed_csp4_settings_content' => 'a:9:{s:6:"status";s:1:"0";s:4:"logo";s:0:"";s:8:"headline";s:49:"Get Ready... Something Really Cool Is Coming Soon";s:11:"description";s:0:"";s:13:"footer_credit";s:1:"0";s:7:"favicon";s:0:"";s:9:"seo_title";s:0:"";s:15:"seo_description";s:0:"";s:12:"ga_analytics";s:0:"";}',
  'seed_csp4_settings_design' => 'a:12:{s:8:"bg_color";s:7:"#fafafa";s:8:"bg_image";s:0:"";s:8:"bg_cover";a:1:{i:0;s:1:"1";}s:9:"bg_repeat";s:9:"no-repeat";s:11:"bg_position";s:8:"left top";s:13:"bg_attahcment";s:5:"fixed";s:9:"max_width";s:0:"";s:10:"text_color";s:7:"#666666";s:10:"link_color";s:7:"#27AE60";s:14:"headline_color";s:7:"#444444";s:9:"text_font";s:6:"_arial";s:10:"custom_css";s:0:"";}',
  'seed_csp4_settings_advanced' => 'a:2:{s:14:"header_scripts";s:0:"";s:14:"footer_scripts";s:0:"";}',
);